#!/bin/bash
source .venv/bin/activate
python app/main.py
